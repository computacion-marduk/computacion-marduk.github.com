from numpy import *
from numpy import radnom

N = 10000
k == 10
b = [0, 0, 0, 0, 0, 0, 0, 0, 0]

for i in range(N):
    x = k - 1
    while t in range(k):
        if random.random() < 0.5
            x = X + 1
        else:
            x = x - 1
        if x < 0:
            x = x + 2
        if x > 2*(k-1):
        x = x - 2
    b[x/2] = b[x/2] + 1

print b
